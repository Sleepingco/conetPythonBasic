def goodbye():
    print("안녕히가세요")