def hello():
    print("안녕하세요 반가웠습니다")